package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="data_src")

public class USDASourceOfDataFile {

	@DatabaseField private String datasrc_id;
	@DatabaseField private String authors;
	@DatabaseField private String title;
	@DatabaseField private String year;
	@DatabaseField private String journal;
	@DatabaseField private String vol_city;
	@DatabaseField private String issue_state;
	@DatabaseField private String start_page;
	@DatabaseField private String end_page;

	public String getDatasrc_id() {
		return datasrc_id;
	}
	public void setDatasrc_id(String datasrc_id) {
		this.datasrc_id = datasrc_id;
	}
	public String getAuthors() {
		return authors;
	}
	public void setAuthors(String authors) {
		this.authors = authors;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getJournal() {
		return journal;
	}
	public void setJournal(String journal) {
		this.journal = journal;
	}
	public String getVol_city() {
		return vol_city;
	}
	public void setVol_city(String vol_city) {
		this.vol_city = vol_city;
	}
	public String getIssue_state() {
		return issue_state;
	}
	public void setIssue_state(String issue_state) {
		this.issue_state = issue_state;
	}
	public String getStart_page() {
		return start_page;
	}
	public void setStart_page(String start_page) {
		this.start_page = start_page;
	}
	public String getEnd_page() {
		return end_page;
	}
	public void setEnd_page(String end_page) {
		this.end_page = end_page;
	}
}
