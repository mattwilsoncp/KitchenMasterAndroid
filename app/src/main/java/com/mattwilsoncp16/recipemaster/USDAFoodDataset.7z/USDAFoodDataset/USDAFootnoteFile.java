package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="footnote")

public class USDAFootnoteFile {

	@DatabaseField private Integer ndb_no;
	@DatabaseField private Integer footnt_no;
	@DatabaseField private String footnt_typ;
	@DatabaseField private Integer nutr_no;
	@DatabaseField private String footnt_txt;
	
	public Integer getNdb_no() {
		return ndb_no;
	}
	public void setNdb_no(Integer ndb_no) {
		this.ndb_no = ndb_no;
	}
	public Integer getFootnt_no() {
		return footnt_no;
	}
	public void setFootnt_no(Integer footnt_no) {
		this.footnt_no = footnt_no;
	}
	public String getFootnt_typ() {
		return footnt_typ;
	}
	public void setFootnt_typ(String footnt_typ) {
		this.footnt_typ = footnt_typ;
	}
	public Integer getNutr_no() {
		return nutr_no;
	}
	public void setNutr_no(Integer nutr_no) {
		this.nutr_no = nutr_no;
	}
	public String getFootnt_txt() {
		return footnt_txt;
	}
	public void setFootnt_txt(String footnt_txt) {
		this.footnt_txt = footnt_txt;
	}
	
}
