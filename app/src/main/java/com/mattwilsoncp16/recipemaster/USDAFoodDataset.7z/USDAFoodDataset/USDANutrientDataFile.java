package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="nut_data")

public class USDANutrientDataFile {

    @DatabaseField(foreign=true, columnName="ndb_no") 
	private USDAFoodDescriptionFile foodDescriptionFile;
     
    @DatabaseField private Integer ndb_no;
	@DatabaseField private Integer nutr_no;

	@DatabaseField private String nutr_val;
	@DatabaseField private String num_data_pts;
	@DatabaseField private String std_error;
	@DatabaseField private String src_cd;
	@DatabaseField private String deriv_cd;
	@DatabaseField private String ref_ndb_no;
	@DatabaseField private String add_nutr_mark;
	@DatabaseField private String num_studies;
	@DatabaseField private String min;
	@DatabaseField private String max;
	@DatabaseField private String df;
	@DatabaseField private String low_eb;
	@DatabaseField private String up_eb;
	@DatabaseField private String stat_cmt;
	@DatabaseField private String addmod_date;
	@DatabaseField private String cc;
	
	@DatabaseField(foreign=true, foreignAutoRefresh=true, columnName="nutr_no")
	private USDANutrientDefinitionFile nutrientDefinitionFile;
	
	public String toString() {
		return nutrientDefinitionFile.getNutrdesc() + ": " + this.getNutr_val() + nutrientDefinitionFile.getUnits();
	}

	public Integer getNutr_no() {
		return nutr_no;
	}
	public void setNutr_no(Integer nutr_no) {
		this.nutr_no = nutr_no;
	}
	public String getNutr_val() {
		return nutr_val;
	}
	public void setNutr_val(String nutr_val) {
		this.nutr_val = nutr_val;
	}
	public String getNum_data_pts() {
		return num_data_pts;
	}
	public void setNum_data_pts(String num_data_pts) {
		this.num_data_pts = num_data_pts;
	}
	public String getStd_error() {
		return std_error;
	}
	public void setStd_error(String std_error) {
		this.std_error = std_error;
	}
	public String getSrc_cd() {
		return src_cd;
	}
	public void setSrc_cd(String src_cd) {
		this.src_cd = src_cd;
	}
	public String getDeriv_cd() {
		return deriv_cd;
	}
	public void setDeriv_cd(String deriv_cd) {
		this.deriv_cd = deriv_cd;
	}
	public String getRef_ndb_no() {
		return ref_ndb_no;
	}
	public void setRef_ndb_no(String ref_ndb_no) {
		this.ref_ndb_no = ref_ndb_no;
	}
	public String getAdd_nutr_mark() {
		return add_nutr_mark;
	}
	public void setAdd_nutr_mark(String add_nutr_mark) {
		this.add_nutr_mark = add_nutr_mark;
	}
	public String getNum_studies() {
		return num_studies;
	}
	public void setNum_studies(String num_studies) {
		this.num_studies = num_studies;
	}
	public String getMin() {
		return min;
	}
	public void setMin(String min) {
		this.min = min;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getDf() {
		return df;
	}
	public void setDf(String df) {
		this.df = df;
	}
	public String getLow_eb() {
		return low_eb;
	}
	public void setLow_eb(String low_eb) {
		this.low_eb = low_eb;
	}
	public String getUp_eb() {
		return up_eb;
	}
	public void setUp_eb(String up_eb) {
		this.up_eb = up_eb;
	}
	public String getStat_cmt() {
		return stat_cmt;
	}
	public void setStat_cmt(String stat_cmt) {
		this.stat_cmt = stat_cmt;
	}
	public String getAddmod_date() {
		return addmod_date;
	}
	public void setAddmod_date(String addmod_date) {
		this.addmod_date = addmod_date;
	}
	public String getCc() {
		return cc;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	
}
