package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.mattwilsoncp16.recipemaster.R;

public class USDADatabaseHelper extends OrmLiteSqliteOpenHelper {

    private static final String DATABASE_NAME = "helloAndroid.db";
    private static final int DATABASE_VERSION = 1;
    private Dao<SimpleData, Integer> simpleDao = null;
    private RuntimeExceptionDao<SimpleData, Integer> simpleRuntimeDao = null;

    public USDADatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION, R.raw.ormlite_config);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, ConnectionSource connectionSource, int oldVersion, int newVersion) {

    }

    @Override
    public void onCreate(SQLiteDatabase database, ConnectionSource connectionSource) {

    }
}
