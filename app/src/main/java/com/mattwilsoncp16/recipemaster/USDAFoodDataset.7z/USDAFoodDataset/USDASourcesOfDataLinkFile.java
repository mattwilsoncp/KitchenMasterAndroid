package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="datsrcln")
public class USDASourcesOfDataLinkFile {

	@DatabaseField private Integer ndb_no;
	@DatabaseField private Integer nutr_no;
	@DatabaseField private String datasrc_id;
	
	public Integer getNdb_no() {
		return ndb_no;
	}
	public void setNdb_no(Integer ndb_no) {
		this.ndb_no = ndb_no;
	}
	public Integer getNutr_no() {
		return nutr_no;
	}
	public void setNutr_no(Integer nutr_no) {
		this.nutr_no = nutr_no;
	}
	public String getDatasrc_id() {
		return datasrc_id;
	}
	public void setDatasrc_id(String datasrc_id) {
		this.datasrc_id = datasrc_id;
	}
}
