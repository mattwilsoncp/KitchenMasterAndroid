package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="src_cd")
public class USDASourceCodeFile {
	@DatabaseField(id=true) private String src_cd;
	@DatabaseField private String srccd_desc;
	
	public String getSrc_cd() {
		return src_cd;
	}
	public void setSrc_cd(String src_cd) {
		this.src_cd = src_cd;
	}
	public String getSrccd_desc() {
		return srccd_desc;
	}
	public void setSrccd_desc(String srccd_desc) {
		this.srccd_desc = srccd_desc;
	}
	
}
