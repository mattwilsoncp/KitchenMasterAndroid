package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.stmt.QueryBuilder;

public class USDADataset {

	private DatabaseConnection usdaConnection;
	private Dao<USDAFoodDescriptionFile, String> foodDescriptionFileDao;

	public USDADataset(String datasourceLocation) {
		setDatasetLocation(datasourceLocation);
		try {
			setFoodDescriptionFileDao(DaoManager.createDao(usdaConnection.getConnSource(), USDAFoodDescriptionFile.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void setDatasetLocation(String url) {
		setUsdaConnection(new DatabaseConnection(url));
	}

	public DatabaseConnection getUsdaConnection() {
		return usdaConnection;
	}

	public void setUsdaConnection(DatabaseConnection usdaConnection) {
		this.usdaConnection = usdaConnection;
	}

	public Dao<USDAFoodDescriptionFile, String> getFoodDescriptionFileDao() {
		return foodDescriptionFileDao;
	}

	public void setFoodDescriptionFileDao(Dao<USDAFoodDescriptionFile, String> foodDescriptionFileDao) {
		this.foodDescriptionFileDao = foodDescriptionFileDao;
	}

	//Get a list of Food Description File objects
	//params: String shortDescription - The USDA Food description file short description.  It will be
	//converted to upper case before the query is executed.
	public List<USDAFoodDescriptionFile> findFoodByShortDescription(String shortDescription) {

		List<USDAFoodDescriptionFile> fdf = new ArrayList<USDAFoodDescriptionFile>();
		QueryBuilder<USDAFoodDescriptionFile, String> statementBuilder = this.foodDescriptionFileDao.queryBuilder();
		try {
			statementBuilder.where().like("shrt_desc", "%" + shortDescription.toUpperCase() + "%");
			fdf.addAll(foodDescriptionFileDao.query(statementBuilder.prepare()));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fdf;
	}

	//Add a food to the USDA data set
	public void addUSDAFood(USDAFoodDescriptionFile fdf) {
		if(fdf.getFoodGroupDescriptionFile() == null) {
			
		}
	}
	

}
