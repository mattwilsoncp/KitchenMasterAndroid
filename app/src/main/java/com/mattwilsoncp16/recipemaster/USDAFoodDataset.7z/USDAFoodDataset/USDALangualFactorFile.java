package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="langual")

public class USDALangualFactorFile {
	@DatabaseField private Integer ndb_no;
	@DatabaseField private String factor_code;
}
