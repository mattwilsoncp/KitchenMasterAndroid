package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="langdesc")

public class USDALangualFactorsDescriptionFile {

	@DatabaseField private String factor_code;
	@DatabaseField private String description;
	
	public String getFactor_code() {
		return factor_code;
	}
	public void setFactor_code(String factor_code) {
		this.factor_code = factor_code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
