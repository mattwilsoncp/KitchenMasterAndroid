package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="weight")
public class USDAWeightFile {
	
	@DatabaseField private Integer ndb_no;
	@DatabaseField private Integer seq;
	@DatabaseField private Double amount;
	@DatabaseField private String msre_desc;
	@DatabaseField private String gm_wgt;
	@DatabaseField private String num_data_pts;
	@DatabaseField private String std_dev;
	
	public Integer getNdb_no() {
		return ndb_no;
	}
	public void setNdb_no(Integer ndb_no) {
		this.ndb_no = ndb_no;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getMsre_desc() {
		return msre_desc;
	}
	public void setMsre_desc(String msre_desc) {
		this.msre_desc = msre_desc;
	}
	public String getGm_wgt() {
		return gm_wgt;
	}
	public void setGm_wgt(String gm_wgt) {
		this.gm_wgt = gm_wgt;
	}
	public String getNum_data_pts() {
		return num_data_pts;
	}
	public void setNum_data_pts(String num_data_pts) {
		this.num_data_pts = num_data_pts;
	}
	public String getStd_dev() {
		return std_dev;
	}
	public void setStd_dev(String std_dev) {
		this.std_dev = std_dev;
	}
}
