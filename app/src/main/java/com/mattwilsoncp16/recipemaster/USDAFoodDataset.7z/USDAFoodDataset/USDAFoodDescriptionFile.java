package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="food_des")
public class USDAFoodDescriptionFile {
	
	@DatabaseField(id=true) private Integer ndb_no;
	@DatabaseField private String long_desc;
	@DatabaseField private String shrt_desc;
    @DatabaseField private String comname;
    @DatabaseField private String manufacname;
    @DatabaseField private String survey;
    @DatabaseField private String ref_desc;
    @DatabaseField private String refuse;
    @DatabaseField private String sciname;
	@DatabaseField private String n_factor;
	@DatabaseField private String pro_factor;
	@DatabaseField private String fat_factor;
	@DatabaseField private String cho_factor;
	
	@DatabaseField(foreign=true, foreignAutoRefresh=true, columnName="fdgrp_cd")
	private USDAFoodGroupDescriptionFile foodGroupDescriptionFile;
	
	public USDAFoodDescriptionFile() {}

	public Integer getNdb_no() {
		return ndb_no;
	}

	public void setNdb_no(Integer ndb_no) {
		this.ndb_no = ndb_no;
	}

	public String getLong_desc() {
		return long_desc;
	}

	public USDAFoodGroupDescriptionFile getFoodGroupDescriptionFile() {
		return foodGroupDescriptionFile;
	}

	public void setFoodGroupDescriptionFile(USDAFoodGroupDescriptionFile foodGroupDescriptionFile) {
		this.foodGroupDescriptionFile = foodGroupDescriptionFile;
	}

	public void setLong_desc(String long_desc) {
		this.long_desc = long_desc;
	}

	public String getShrt_desc() {
		return shrt_desc;
	}

	public void setShrt_desc(String shrt_desc) {
		this.shrt_desc = shrt_desc;
	}

	public String getComname() {
		return comname;
	}

	public void setComname(String comname) {
		this.comname = comname;
	}

	public String getManufacname() {
		return manufacname;
	}

	public void setManufacname(String manufacname) {
		this.manufacname = manufacname;
	}

	public String getSurvey() {
		return survey;
	}

	public void setSurvey(String survey) {
		this.survey = survey;
	}

	public String getRef_desc() {
		return ref_desc;
	}

	public void setRef_desc(String ref_desc) {
		this.ref_desc = ref_desc;
	}

	public String getRefuse() {
		return refuse;
	}

	public void setRefuse(String refuse) {
		this.refuse = refuse;
	}

	public String getSciname() {
		return sciname;
	}

	public void setSciname(String sciname) {
		this.sciname = sciname;
	}

	public String getN_factor() {
		return n_factor;
	}

	public void setN_factor(String n_factor) {
		this.n_factor = n_factor;
	}

	public String getPro_factor() {
		return pro_factor;
	}

	public void setPro_factor(String pro_factor) {
		this.pro_factor = pro_factor;
	}

	public String getFat_factor() {
		return fat_factor;
	}

	public void setFat_factor(String fat_factor) {
		this.fat_factor = fat_factor;
	}

	public String getCho_factor() {
		return cho_factor;
	}

	public void setCho_factor(String cho_factor) {
		this.cho_factor = cho_factor;
	}
	
	public String toString() {
		String str =  this.long_desc;
		
		return str;
	}

	


}
