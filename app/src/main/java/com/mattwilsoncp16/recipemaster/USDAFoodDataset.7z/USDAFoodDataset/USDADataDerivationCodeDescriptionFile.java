package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="deriv_cd")

public class USDADataDerivationCodeDescriptionFile {

	@DatabaseField private String deriv_cd;
	@DatabaseField private String deriv_desc;
	
	
	public String getDeriv_cd() {
		return deriv_cd;
	}
	public void setDeriv_cd(String deriv_cd) {
		this.deriv_cd = deriv_cd;
	}
	public String getDeriv_desc() {
		return deriv_desc;
	}
	public void setDeriv_desc(String deriv_desc) {
		this.deriv_desc = deriv_desc;
	}
}
