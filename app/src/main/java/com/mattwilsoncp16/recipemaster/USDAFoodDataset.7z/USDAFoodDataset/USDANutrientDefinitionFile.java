package com.mattwilsoncp16.recipemaster.USDAFoodDataset;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName="nutr_def")

public class USDANutrientDefinitionFile {
	
	@DatabaseField(id=true) private Integer nutr_no;
	@DatabaseField private String units;
	@DatabaseField private String tagname;
	@DatabaseField private String nutrdesc;
	@DatabaseField private String num_dec;
	@DatabaseField private String sr_order;
	
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getTagname() {
		return tagname;
	}
	public void setTagname(String tagname) {
		this.tagname = tagname;
	}
	public String getNutrdesc() {
		return nutrdesc;
	}
	public void setNutrdesc(String nutrdesc) {
		this.nutrdesc = nutrdesc;
	}
	public String getNum_dec() {
		return num_dec;
	}
	public void setNum_dec(String num_dec) {
		this.num_dec = num_dec;
	}
	public String getSr_order() {
		return sr_order;
	}
	public void setSr_order(String sr_order) {
		this.sr_order = sr_order;
	}
	
}
